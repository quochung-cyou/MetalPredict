import tkinter as tk
from tkinter import ttk, messagebox
from traditional_predictor import TraditionalGoldPredictor
import pandas as pd
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np

class GoldPredictionGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Gold Price Prediction - Traditional Model")
        self.root.geometry("1200x800")
        
        # Initialize predictor
        self.predictor = TraditionalGoldPredictor()
        
        # Create main frame
        self.main_frame = ttk.Frame(self.root, padding="10")
        self.main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Control Panel
        self.create_control_panel()
        
        # Results Area
        self.create_results_area()
        
        # Plot Area
        self.create_plot_area()
        
        # Configure weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        self.main_frame.columnconfigure(1, weight=1)
        self.main_frame.rowconfigure(2, weight=1)
        
        # Initial load
        self.load_data()

    def create_control_panel(self):
        control_frame = ttk.LabelFrame(self.main_frame, text="Controls", padding="5")
        control_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        
        # Train button
        self.train_btn = ttk.Button(control_frame, text="Train Model", command=self.train_model)
        self.train_btn.grid(row=0, column=0, padx=5)
        
        # Predict button
        self.predict_btn = ttk.Button(control_frame, text="Make Predictions", command=self.make_predictions)
        self.predict_btn.grid(row=0, column=1, padx=5)
        
        # Show Metrics button
        self.metrics_btn = ttk.Button(control_frame, text="Show Metrics", command=self.show_metrics)
        self.metrics_btn.grid(row=0, column=2, padx=5)

    def create_results_area(self):
        # Create results frame
        results_frame = ttk.LabelFrame(self.main_frame, text="Latest Predictions", padding="5")
        results_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=5)
        
        # Create treeview for predictions
        self.tree = ttk.Treeview(results_frame, columns=('Date', 'Price', 'Low', 'High'), show='headings', height=5)
        self.tree.heading('Date', text='Date')
        self.tree.heading('Price', text='Predicted Price')
        self.tree.heading('Low', text='Lower Bound')
        self.tree.heading('High', text='Upper Bound')
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        # Grid layout
        self.tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # Configure grid weights
        results_frame.columnconfigure(0, weight=1)

    def create_plot_area(self):
        # Create plot frame
        plot_frame = ttk.LabelFrame(self.main_frame, text="Price History and Predictions", padding="5")
        plot_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        
        # Create figure with subplots
        self.fig = Figure(figsize=(12, 6), dpi=100)
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def load_data(self):
        try:
            # Train model if not already trained
            if not self.predictor.model:
                self.predictor.train()
            self.make_predictions()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load data: {str(e)}")

    def train_model(self):
        try:
            self.predictor.train(force_retrain=True)
            messagebox.showinfo("Success", "Model trained successfully!")
            self.make_predictions()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to train model: {str(e)}")

    def make_predictions(self):
        try:
            # Get historical data
            historical_df = pd.read_csv(self.predictor.data_path)
            historical_df['Date'] = pd.to_datetime(historical_df['Date'])
            historical_df['Price'] = historical_df['Price'].astype(str).str.replace(',', '').astype(float)
            
            # Get predictions for all historical dates plus 30 days into future
            start_date = historical_df['Date'].min().strftime('%Y-%m-%d')
            end_date = (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d')
            all_predictions = self.predictor.predict(start_date=start_date, end_date=end_date, regenerate=True)
            
            # Convert predictions to DataFrame
            pred_df = pd.DataFrame(all_predictions)
            pred_df['date'] = pd.to_datetime(pred_df['date'])
            pred_df = pred_df.rename(columns={'date': 'Date', 'predicted_price': 'Predicted'})
            
            # Update plot with both lines
            self.update_plot(historical_df, pred_df)
            
            # Show only future predictions in the table
            last_date = historical_df['Date'].max()
            future_predictions = [p for p in all_predictions if pd.to_datetime(p['date']) > last_date]
            
            # Clear and update treeview
            for item in self.tree.get_children():
                self.tree.delete(item)
                
            for pred in future_predictions:
                self.tree.insert('', 'end', values=(
                    pred['date'],
                    f"{pred['predicted_price']:.2f}",
                    f"{pred['predicted_price_low']:.2f}",
                    f"{pred['predicted_price_high']:.2f}"
                ))
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to make predictions: {str(e)}")

    def update_plot(self, historical_df, pred_df):
        self.fig.clear()
        ax = self.fig.add_subplot(111)
        
        # Plot actual prices
        ax.plot(historical_df['Date'], historical_df['Price'], 
                'b-', label='Actual Price', linewidth=2)
        
        # Plot predicted prices
        ax.plot(pred_df['Date'], pred_df['Predicted'],
                'r--', label='Predicted Price', linewidth=2)
        
        # Customize the plot
        ax.set_xlabel('Date')
        ax.set_ylabel('Gold Price')
        ax.set_title('Gold Price - Actual vs Predicted')
        ax.legend(loc='upper left')
        ax.grid(True, linestyle='--', alpha=0.7)
        
        # Rotate x-axis labels
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
        
        self.fig.tight_layout()
        self.canvas.draw()

    def show_metrics(self):
        try:
            metrics = self.predictor.get_model_metrics()
            message = f"Model Metrics:\n\n"
            message += f"MSE: {metrics['mse']:.2f}\n"
            message += f"RMSE: {metrics['rmse']:.2f}\n"
            message += f"MAE: {metrics['mae']:.2f}"
            messagebox.showinfo("Model Metrics", message)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to get metrics: {str(e)}")

def main():
    root = tk.Tk()
    app = GoldPredictionGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
